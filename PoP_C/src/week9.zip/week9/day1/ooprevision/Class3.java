package week9.day1.ooprevision;

public class Class3 extends Class2{

}
