package week9.day1.ooprevision;

public class Class1 {
	private int num1;
	int num3; //default
	public int num4;
	protected int num5;
}

//100 programs - used
