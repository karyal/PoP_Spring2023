package week9.day1.ooprevision;

public class Class2 extends Class1{
	private int num2;
	
	public Class2() {
		
	}
	public Class2(int num1, int num2) {
		
	}
	
	public Class2(int num1) {
		
	}
}
